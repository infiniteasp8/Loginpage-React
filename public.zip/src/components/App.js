import React from "react";
// import Login from "./Login";


// var isLoggedIn = true;
 
function App () {  
    <div className="container">
        {/* <Login /> */}
        <p>Hello World</p>
        {/* {isLoggedIn ? <p>Hello World</p> : <Login />} */}
    </div>
}

export default App;